package com.example.librosd;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Libros extends AppCompatActivity {
    private SQLiteDatabase db;
    private EditText editTextNumber_IDBOOK, editTextText3_NAME, editTextNumber2;
    private Button button2_guardar, button3_editar, button4_bucar, button5_eliminar;
       Button button_backup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.book);

        editTextNumber_IDBOOK = findViewById(R.id.editTextNumber_IDBOOK);
        editTextText3_NAME = findViewById(R.id.editTextText3_NAME);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        button2_guardar = findViewById(R.id.button2_guardar);
        button3_editar = findViewById(R.id.button3_editar);
        button4_bucar = findViewById(R.id.button4_bucar);
        button5_eliminar = findViewById(R.id.button5_eliminar);
        button_backup=findViewById(R.id.button_backup);

        DbHelper dbHelper = new DbHelper(Libros.this, "Registro", null, 1);
        db = dbHelper.getWritableDatabase();

        // Crear la tabla si no existe
        db.execSQL("CREATE TABLE IF NOT EXISTS BOOK (IDBOOK INTEGER PRIMARY KEY, NOMBRE TEXT, COSTO INTEGER, VALIDO INTEGER NOT NULL)");


      /**  button_backup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent retorno = new Intent(Libros.this, Rentar.class);
                startActivity(retorno );
            }
        }); **/

        // Configurar los listeners para los botones
        button2_guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertarLibro();
            }
        });

        button3_editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actualizarLibro();
            }
        });

        button4_bucar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarLibro();
            }
        });

        button5_eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminarLibro();
            }
        });
    }

    public  void retornar(){
       Intent regresar = new Intent(Libros.this,Rentar.class);
       startActivity(regresar);
    }
    private void insertarLibro() {
        String nombre = editTextText3_NAME.getText().toString();
        int costo = Integer.parseInt(editTextNumber2.getText().toString());
        int valido = 1; // Asumimos que el valor de "válido" es 1 por defecto

        ContentValues values = new ContentValues();
        values.put("NOMBRE", nombre);
        values.put("COSTO", costo);
        values.put("VALIDO", valido);

        long newRowId = db.insert("BOOK", null, values);
        if (newRowId != -1) {
            Toast.makeText(Libros.this, "Libro insertado correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Libros.this, "Error al insertar el libro", Toast.LENGTH_SHORT).show();
        }
    }

    private void actualizarLibro() {
        int idbook = Integer.parseInt(editTextNumber_IDBOOK.getText().toString());
        String nombre = editTextText3_NAME.getText().toString();
        int costo = Integer.parseInt(editTextNumber2.getText().toString());

        ContentValues values = new ContentValues();
        values.put("NOMBRE", nombre);
        values.put("COSTO", costo);

        int rowsAffected = db.update("BOOK", values, "IDBOOK = ?", new String[]{String.valueOf(idbook)});
        if (rowsAffected > 0) {
            Toast.makeText(Libros.this, "Libro actualizado correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Libros.this, "Error al actualizar el libro", Toast.LENGTH_SHORT).show();
        }
    }

    private void buscarLibro() {
        int idbook = Integer.parseInt(editTextNumber_IDBOOK.getText().toString());

        Cursor cursor = db.query("BOOK", null, "IDBOOK = ?", new String[]{String.valueOf(idbook)}, null, null, null);
        if (cursor.moveToFirst()) {
            String nombre = cursor.getString(0);
            int costo = cursor.getInt(1);
            int valido = cursor.getInt(2);

            editTextText3_NAME.setText(nombre);
            editTextNumber2.setText(String.valueOf(costo));

            Toast.makeText(Libros.this, "Libro encontrado: " + nombre + ", Costo: " + costo + ", Válido: " + valido, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Libros.this, "Libro no encontrado", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    private void eliminarLibro() {
        int idbook = Integer.parseInt(editTextNumber_IDBOOK.getText().toString());

        int rowsAffected = db.delete("BOOK", "IDBOOK = ?", new String[]{String.valueOf(idbook)});
        if (rowsAffected > 0) {
            Toast.makeText(Libros.this, "Libro eliminado correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Libros.this, "Error al eliminar el libro", Toast.LENGTH_SHORT).show();
        }
    }
}
