package com.example.librosd;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UsuarioLogin extends AppCompatActivity {
EditText editTextText, editTextText2;
Button button_SIGNUP, button2_LOGIN;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.usuariologin);
        DbHelper dbHelper= new DbHelper(UsuarioLogin.this, "Registro",null, 1);
        SQLiteDatabase DBReader= dbHelper.getReadableDatabase();
        editTextText=findViewById(R.id. editTextText);
        editTextText2=findViewById(R.id. editTextText2);
        button_SIGNUP=findViewById(R.id. button_SIGNUP);
        button2_LOGIN=findViewById(R.id. button2_LOGIN);

        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario= editTextText.getText().toString();
                String contrasena= editTextText2.getText().toString();
                if(v.getId()== R.id.button_SIGNUP){
                    Intent siguiente= new Intent(UsuarioLogin.this, UsuarioSigUp.class);
                    startActivity(siguiente);

                }else if(v.getId()== R.id.button2_LOGIN){
                    Cursor cursor = DBReader.rawQuery("SELECT * FROM USUARIO WHERE EMAIL = ? AND PASSAWORD = ?", new String[]{usuario, contrasena});
                    if (cursor.moveToFirst()) {
                            // Si el cursor no está vacío, significa que se encontró un usuario con las credenciales proporcionadas
                            // Puedes realizar acciones adicionales aquí, como iniciar la siguiente actividad o mostrar un mensaje de éxito
                            Toast.makeText(UsuarioLogin.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();



                    } else {
                        Intent siguiente = new Intent(UsuarioLogin.this, Rentar.class);
                        startActivity(siguiente);
                        // Si el cursor está vacío, significa que no se encontró ningún usuario con las credenciales proporcionadas
                        // Puedes mostrar un mensaje de error o realizar cualquier otra acción que desees

                    }
                    cursor.close();


                }
            }
        };

        for(Button button: new Button[]{button_SIGNUP, button2_LOGIN}){
            button.setOnClickListener(onClickListener);
        }

    }
}
