package com.example.librosd;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Rentar extends AppCompatActivity {
    private SQLiteDatabase db;
    private EditText editTextNumber_NUMBER, editTextNumber, editTextNumber3, editTextText3;
    private Button buttonAgregar, buttonLibro;
    private ListView listViewRentas;
    private ArrayList<String> rentasList;
    private ArrayAdapter<String> rentasAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rentar);

        buttonAgregar = findViewById(R.id.buttonAgregar);
        editTextNumber_NUMBER = findViewById(R.id.editTextNumber_NUMBER);
        editTextNumber = findViewById(R.id.editTextNumber);
        editTextNumber3 = findViewById(R.id.editTextNumber3);
        editTextText3 = findViewById(R.id.editTextText3);
        buttonLibro = findViewById(R.id.buttonLibro);
        listViewRentas = findViewById(R.id.listViewRentas);

        DbHelper dbHelper = new DbHelper(Rentar.this, "Registro", null, 1);
        db = dbHelper.getWritableDatabase();

        db.execSQL("CREATE TABLE IF NOT EXISTS RENTA (IDRENTA INTEGER PRIMARY KEY, IDUSER INTEGER, IDBOOK INTEGER, FECHA TEXT, FOREIGN KEY (IDUSER) REFERENCES USUARIO(IDUSER), FOREIGN KEY (IDBOOK) REFERENCES BOOK(IDBOOK))");

        rentasList = new ArrayList<>();
        rentasAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rentasList);
        listViewRentas.setAdapter(rentasAdapter);

        buttonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertarRenta();
            }
        });

        buttonLibro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Libros.class);
                startActivity(i);
            }
        });

        mostrarRentas();
    }

    private void insertarRenta() {
        try {
            int idRenta = Integer.parseInt(editTextNumber_NUMBER.getText().toString());
            int idUser = Integer.parseInt(editTextNumber.getText().toString());
            int idBook = Integer.parseInt(editTextNumber3.getText().toString());
            String fecha = editTextText3.getText().toString();

            Cursor cursorUser = db.rawQuery("SELECT IDUSER FROM USUARIO WHERE IDUSER = ?", new String[]{String.valueOf(idUser)});
            if (cursorUser.moveToFirst()) {
                Cursor cursorBook = db.rawQuery("SELECT IDBOOK FROM BOOK WHERE IDBOOK = ?", new String[]{String.valueOf(idBook)});
                if (cursorBook.moveToFirst()) {
                    ContentValues values = new ContentValues();
                    values.put("IDRENTA", idRenta);
                    values.put("IDUSER", idUser);
                    values.put("IDBOOK", idBook);
                    values.put("FECHA", fecha);

                    long newRowId = db.insert("RENTA", null, values);
                    if (newRowId != -1) {
                        Toast.makeText(Rentar.this, "Renta insertada correctamente", Toast.LENGTH_SHORT).show();
                        mostrarRentas(); // Actualizar la lista de rentas
                    } else {
                        Toast.makeText(Rentar.this, "Error al insertar la renta", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(Rentar.this, "El IDBOOK no existe en la tabla BOOK", Toast.LENGTH_SHORT).show();
                }
                cursorBook.close();
            } else {
                Toast.makeText(Rentar.this, "El IDUSER no existe en la tabla USUARIO", Toast.LENGTH_SHORT).show();
            }
            cursorUser.close();
        } catch (NumberFormatException e) {
            Toast.makeText(Rentar.this, "Por favor, ingrese números válidos", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarRentas() {
        rentasList.clear();
        Cursor cursor = db.rawQuery("SELECT * FROM RENTA", null);
        if (cursor.moveToFirst()) {
            do {
                int idRenta = cursor.getInt(0);
                int idUser = cursor.getInt(1);
                int idBook = cursor.getInt(2);
                String fecha = cursor.getString(3);
                rentasList.add("ID Renta: " + idRenta + ", ID User: " + idUser + ", ID Book: " + idBook + ", Fecha: " + fecha);
            } while (cursor.moveToNext());
        }
        cursor.close();
        rentasAdapter.notifyDataSetChanged();
    }
}
