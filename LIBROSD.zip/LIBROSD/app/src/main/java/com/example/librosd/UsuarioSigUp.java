package com.example.librosd;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UsuarioSigUp extends AppCompatActivity {
    EditText editTextNumber_IDUSER, editTextText_NAME, editTextText2_EMAIL, editTextText3_PASSWORD;
    Button button_SIGNUP, button_LOGIN;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.usuariosignup);
        editTextNumber_IDUSER= findViewById(R.id.editTextNumber_IDUSER);
        editTextText_NAME= findViewById(R.id.editTextText_NAME);
        editTextText2_EMAIL= findViewById(R.id.editTextText2_EMAIL);
        editTextText3_PASSWORD= findViewById(R.id.editTextText3_PASSWORD);
        button_SIGNUP= findViewById(R.id.button_SIGNUP);
        button_LOGIN= findViewById(R.id.button_LOGIN);

        DbHelper dbHelper= new DbHelper(UsuarioSigUp.this, "Registro",null, 1);
        String cadena= String.valueOf(dbHelper.getDatabaseName());

        Toast.makeText(this, cadena, Toast.LENGTH_SHORT).show();
        SQLiteDatabase DbWriter= dbHelper.getWritableDatabase();
        SQLiteDatabase DBReader= dbHelper.getReadableDatabase();

        View.OnClickListener onClickListener = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String iduser= editTextNumber_IDUSER.getText().toString();
                String name= editTextText_NAME.getText().toString();
                String email= editTextText2_EMAIL.getText().toString();
                String password= editTextText3_PASSWORD.getText().toString();
                if(v.getId()== R.id.button_SIGNUP){

                    if(iduser.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty()){
                        editTextNumber_IDUSER.setError("Campo vacio");
                        editTextText_NAME.setError("Campo vacio");
                        editTextText2_EMAIL.setError("Campo vacio");
                        editTextText3_PASSWORD.setError("Campo vacio");
                    }else{
                        ContentValues values = new ContentValues();
                        values.put("IDBOOK", iduser);
                        values.put("NOMBRE", name);
                        values.put("COSTO", email);
                        values.put("VALIDO", password);
                        DbWriter.insert(" BOOK", null, values);
                        Toast.makeText(UsuarioSigUp.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                    }


                }else if(v.getId()== R.id.button_LOGIN){
                    Intent intent = new Intent(UsuarioSigUp.this, UsuarioLogin.class);
                    startActivity(intent);

                }

            }
        };

        for(Button button: new Button[]{button_SIGNUP, button_LOGIN}){
            button.setOnClickListener(onClickListener);
        }



    }
}
