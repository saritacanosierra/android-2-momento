package com.example.librosd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public DbHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
       db.execSQL("CREATE TABLE USUARIO (IDUSER INTEGER PRIMARY KEY,NOMBRE TEXT NOT NULL,EMAIL TEXT,PASSAWORD TEXT,STATUS_ESTADO INTEGER)");
       db.execSQL("CREATE TABLE BOOK (IDBOOK INTEGER PRIMARY KEY,NOMBRE TEXT,COSTO INTEGER,VALIDO INTEGER NOT NULL)"); //0 representa FALSE y 1 representa TRUE en el estado de valido
        db.execSQL("CREATE TABLE RENTA (IDRENTA INTEGER PRIMARY KEY,IDUSER INTEGER,IDBOOK INTEGER,FECHA TEXT,FOREIGN KEY (IDUSER) REFERENCES USUARIO(IDUSER),FOREIGN KEY (IDBOOK) REFERENCES BOOK(IDBOOK))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS USUARIO");
        db.execSQL("DROP TABLE IF EXISTS BOOK");
        db.execSQL("DROP TABLE IF EXISTS RENTA");
        onCreate(db);

    }
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // Activar las claves foráneas
        if (!db.isReadOnly()) {
            db.execSQL("PRAGMA foreign_keys = ON;");
        }
    }
}
